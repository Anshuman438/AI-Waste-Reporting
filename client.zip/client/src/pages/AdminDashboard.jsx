import React, { useEffect, useState } from "react";
import axios from "axios";

const AdminDashboard = () => {
  const [complaints, setComplaints] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchComplaints = async () => {
    try {
      const token = localStorage.getItem("token");

      const res = await axios.get(
        "http://localhost:5000/api/complaints",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      setComplaints(res.data);
      setLoading(false);
    } catch (error) {
      console.error(error);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchComplaints();
  }, []);

  const updateStatus = async (id, newStatus) => {
    try {
      const token = localStorage.getItem("token");

      await axios.put(
        `http://localhost:5000/api/complaints/${id}`,
        { status: newStatus },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      fetchComplaints();
    } catch (error) {
      console.error(error);
    }
  };

  const statusStyle = (status) => {
    if (status === "pending") return "bg-yellow-200 text-yellow-900";
    if (status === "in-progress") return "bg-blue-200 text-blue-900";
    if (status === "resolved") return "bg-green-200 text-green-900";
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="bg-red-500 text-white text-4xl p-10">
  TEST TAILWIND
</div>
      {/* Header */}
      <div className="bg-white shadow-md p-4">
        <h1 className="text-2xl font-bold text-center">
          Waste Reporting Admin Panel
        </h1>
      </div>
      
      {/* Content */}
      <div className="max-w-6xl mx-auto p-6">

        {loading ? (
          <p className="text-center text-gray-500">
            Loading complaints...
          </p>
        ) : complaints.length === 0 ? (
          <p className="text-center text-gray-500">
            No complaints found.
          </p>
        ) : (
          <div className="grid md:grid-cols-2 gap-6">
            {complaints.map((complaint) => (
              <div
                key={complaint._id}
                className="bg-white rounded-2xl shadow-md overflow-hidden hover:shadow-xl transition"
              >
                <img
                  src={complaint.imageUrl}
                  alt="waste"
                  className="w-full h-56 object-cover"
                />

                <div className="p-4">
                  <div className="flex justify-between items-center mb-2">
                    <h2 className="text-lg font-semibold capitalize">
                      {complaint.wasteType}
                    </h2>

                    <span
                      className={`px-3 py-1 rounded-full text-sm font-medium ${statusStyle(
                        complaint.status
                      )}`}
                    >
                      {complaint.status}
                    </span>
                  </div>

                  <p className="text-gray-600 text-sm mb-2">
                    {complaint.description}
                  </p>

                  <p className="text-xs text-gray-500 mb-4">
                    📍 {complaint.location?.lat}, {complaint.location?.lng}
                  </p>

                  <select
                    value={complaint.status}
                    onChange={(e) =>
                      updateStatus(complaint._id, e.target.value)
                    }
                    className="w-full border p-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
                  >
                    <option value="pending">Pending</option>
                    <option value="in-progress">
                      In Progress
                    </option>
                    <option value="resolved">
                      Resolved
                    </option>
                  </select>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;